
import pandas as pd
import configparser
import ast
import json
import re
from dfcx_scrapi.core.conversation import DialogflowConversation

# -----------------------------
# Helpers: parse parameters_set
# -----------------------------
def parse_params_maybe_dict(value):
    """
    Try to parse 'parameters_set' or 'parameters' into a dict.
    Accepts dict, JSON string, or Python-literal string; returns dict or None.
    """
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        s = value.strip()
        if s == "":
            return None
        # Try JSON first
        try:
            d = json.loads(s)
            if isinstance(d, dict):
                return d
        except Exception:
            pass
        # Fallback to Python literal
        try:
            d = ast.literal_eval(s)
            if isinstance(d, dict):
                return d
        except (ValueError, SyntaxError):
            return None
    return None

def first_nonempty_value(d):
    """Return the first non-empty scalar/string value from dict d; else None."""
    if not isinstance(d, dict) or not d:
        return None
    for v in d.values():
        if v is None:
            continue
        if isinstance(v, str) and v.strip() == "":
            continue
        return v
    return None

def normalize_text(x):
    """Case-insensitive, trims whitespace, removes spaces. Returns None for nulls."""
    if x is None:
        return None
    return str(x).strip().lower().replace(" ", "")

def normalize_and_shorten(s, max_len=20):
    if s is None:
        return ""
    # lower, strip, remove non-alphanumerics, then truncate
    s = re.sub(r'\W+', '', str(s).lower().strip())
    return s[:max_len]

# -----------------------------
# Main
# -----------------------------
# Step 1: Load properties
config = configparser.ConfigParser()
config.read('config.properties')

# Step 2: Read values from property file
agent_id = config.get('dialogflow', 'agent_id')
creds_path = config.get('dialogflow', 'creds_path')

excel_file = config.get('input', 'excel_file')
sheet_name = config.getint('input', 'sheet_name')
flow_display_name = config.get('input', 'flow_display_name')
page_display_name = config.get('input', 'page_display_name')
Utterances = config.get('input', 'Utterances')
intent_column = config.get('input', 'intent_column')

result_file = config.get('output', 'result_file')

# Step 3: Create DialogflowConversation object
conversation = DialogflowConversation(agent_id=agent_id)

# Step 4: Read input Excel
df = pd.read_excel(excel_file, sheet_name=sheet_name)

# Defensive: make sure required input columns exist
for col in [Utterances, intent_column]:
    if col not in df.columns:
        raise ValueError(f"Input column '{col}' not found in sheet '{sheet_name}' of '{excel_file}'.")
    


df[Utterances] = (
    df[Utterances]
    .astype(str)
    .replace({'nan': ''})
    .fillna('')
    .str.strip()
)


# Step 5: Prepare test set using values from properties
test_set = pd.DataFrame({
    "flow_display_name": flow_display_name,
    "page_display_name": page_display_name,
    "utterance": df[Utterances],
    "inject_parameters": "",
    "end_user_metadata": ""
})

# Step 6: Run intent detection
results = conversation.run_intent_detection(test_set, 100, 10)

# Safety checks for returned columns
if 'detected_intent' not in results.columns:
    raise ValueError("Column 'detected_intent' not found in results returned by run_intent_detection.")
if 'confidence' not in results.columns:
    raise ValueError("Column 'confidence' not found in results. Ensure your run_intent_detection returns confidence scores.")

# Add expected intent column from Excel to results
results['expected_intent'] = df[intent_column]

# -----------------------------
# Step 7: Intent match (gated by confidence)
# -----------------------------
# Compare strings first
string_match = (
    results['expected_intent'].astype(str).apply(normalize_text) ==
    results['detected_intent'].astype(str).apply(normalize_text)
)
'''
# Confidence condition
conf_ok = results['confidence'].astype(float) >= 0.3

# Final intent_match = both must be true
results['match'] = string_match & conf_ok
accuracy = results['match'].mean() * 100
results.rename(columns={'match': 'intent_match'}, inplace=True)

'''

# -----------------------------
# Step 7.1: Entity extraction + comparison
# -----------------------------
# Choose parameters column if present
params_col = 'parameters_set' if 'parameters_set' in results.columns else (
    'parameters' if 'parameters' in results.columns else None
)
if params_col is None:
    # Keep schema consistent if parameters not returned
    results['parameters_set'] = None
    params_col = 'parameters_set'

# Extract entity value (first non-empty value from dict, key-agnostic)
results['extracted_entity'] = results[params_col].apply(
    lambda v: first_nonempty_value(parse_params_maybe_dict(v))
)

# Entity match: compare normalized extracted entity with expected_intent
entity_string_match = (
    results['extracted_entity'].apply(normalize_text) ==
    results['expected_intent'].apply(normalize_text)
)

# Optionally gate entity match by confidence as well:
entity_conf_ok = results['confidence'].astype(float) >= 0.3
results['entity_match'] = entity_string_match & entity_conf_ok

# -----------------------------
# Step 7.2: Post-processing rule for NA fills
# -----------------------------
def is_empty_params_cell(v):
    """Treat None/NaN/''/{} or strings that parse to {} as empty."""
    if v is None:
        return True
    # Handle pandas NaN (which is a float but not always)
    try:
        if pd.isna(v):
            return True
    except Exception:
        pass
    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return True
        d = parse_params_maybe_dict(s)
        if isinstance(d, dict) and len(d) == 0:
            return True
        return False
    if isinstance(v, dict):
        return len(v) == 0
    # Other types considered non-empty unless explicitly empty
    return False

# Ensure columns are nullable boolean so NA assignment is valid
results['entity_match'] = results['entity_match'].astype('boolean')
results['intent_match'] = results['intent_match'].astype('boolean')

# Evaluate emptiness on the first 5 rows of parameters_set
first5_empty = results['parameters_set'].head(5).apply(is_empty_params_cell).all()

if first5_empty:
    # If first 5 rows are empty, fill entire entity_match column as NA
    results['entity_match'] = pd.NA
else:
    # Otherwise, fill entire intent_match column as NA
    results['intent_match'] = pd.NA

# -----------------------------
# Step 8: (Optional accuracy column insertion — currently skipped)
# -----------------------------
# If you want accuracy in the file, uncomment below:
# match_idx = results.columns.get_loc('intent_match')
# results.insert(match_idx + 1, 'accuracy', f"{accuracy:.2f}%")

# Step 9: Save results
results.to_csv(result_file, index=False)
print("Results saved to", result_file)